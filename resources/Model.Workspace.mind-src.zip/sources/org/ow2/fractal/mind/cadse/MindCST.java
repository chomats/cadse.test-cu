package org.ow2.fractal.mind.cadse;


import fr.imag.adele.cadse.core.ItemType;
import fr.imag.adele.cadse.core.LinkType;



/**
    @generated
*/
public class MindCST {
	/**
	    @generated
	*/
	public static ItemType COMPONENT;
	/**
	    @generated
	*/
	public static LinkType COMPONENT_lt__$_INVERT_PART_COMPONENTS_TO_PACKAGE;
	/**
	    @generated
	*/
	public static ItemType COMPOSITE;
	/**
	    @generated
	*/
	public static ItemType LIBRARY;
	/**
	    @generated
	*/
	public static LinkType LIBRARY_lt_PACKAGES;
	/**
	    @generated
	*/
	public static ItemType PACKAGE;
	/**
	    @generated
	*/
	public static LinkType PACKAGE_lt__$_INVERT_PART_PACKAGES_TO_LIBRARY;
	/**
	    @generated
	*/
	public static LinkType PACKAGE_lt_COMPONENTS;
	/**
	    @generated
	*/
	public static ItemType PRIMITIVE;

	/**
	    @generated
	*/
	public MindCST() {
	}

}

