package org.ow2.fractal.mind.cadse.managers;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import fede.workspace.eclipse.content.FileContentManager;
import fr.imag.adele.cadse.core.CadseException;
import fr.imag.adele.cadse.core.ContentItem;
import fr.imag.adele.cadse.core.DefaultItemManager;
import fr.imag.adele.cadse.core.Item;
import fr.imag.adele.cadse.core.ItemType;
import fr.imag.adele.cadse.core.Link;
import fr.imag.adele.cadse.core.LinkType;
import fr.imag.adele.cadse.core.delta.ItemDelta;
import fr.imag.adele.cadse.core.impl.var.VariableImpl;
import fr.imag.adele.cadse.core.transaction.AbstractLogicalWorkspaceTransactionListener;
import fr.imag.adele.cadse.core.transaction.LogicalWorkspaceTransaction;
import fr.imag.adele.cadse.core.var.ContextVariable;
import fr.imag.adele.cadse.core.var.Variable;

import org.eclipse.core.resources.IFile;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;
import org.ow2.fractal.mind.cadse.MindCST;

import adl.AdlDefinition;
import adl.AdlFactory;
import adl.ArchitectureDefinition;
import adl.PrimitiveComponentDefinition;



/**
    @generated
*/
public class ComponentManager extends DefaultItemManager {

	/**
	 * This class react to double-click actions on the CADSE views
	 * @author vega
	 *
	 */
	static private final class DoubleClickListener extends AbstractLogicalWorkspaceTransactionListener {
		
		public DoubleClickListener() {
			MindCST.COMPONENT.addLogicalWorkspaceTransactionListener(this);
		}

		@Override
		public void notifyDoubleClick(LogicalWorkspaceTransaction wc, ItemDelta component) {
			IFile contentFile = component.getContentItem().getMainMappingContent(IFile.class);
			if (contentFile != null) {
				try {
					IWorkbench workbench = PlatformUI.getWorkbench();
					IWorkbenchPage activePage = workbench.getActiveWorkbenchWindow().getActivePage();
					IDE.openEditor(activePage, contentFile, true);
				} catch (PartInitException e) {
				}
			}
		}
	}

	@Override
	public void init() {
		if (getItemType() == MindCST.COMPONENT)
			new DoubleClickListener();
	}
	
	/**
	    @generated
	*/
	static final class FileNameVariable extends VariableImpl {

		/**
		    @generated
		*/
		public final static Variable INSTANCE = new FileNameVariable();

		/**
		    @generated
		*/
		public String compute(ContextVariable context, Item itemCurrent) {
			StringBuilder sb = new StringBuilder();
			try {
				Object value;
				sb.append(context.getName(itemCurrent));
				sb.append(".adl");
				return sb.toString();
			} catch (Throwable e) {
				e.printStackTrace();
				return "error";
			}
		}
	}

	/**
	    @generated
	*/
	static final class FilePathVariable extends VariableImpl {

		/**
		    @generated
		*/
		public final static Variable INSTANCE = new FilePathVariable();

		/**
		    @generated
		*/
		public String compute(ContextVariable context, Item itemCurrent) {
			try {
				return "/";
			} catch (Throwable e) {
				e.printStackTrace();
				return "error";
			}
		}
	}

	/**
		@generated
	*/
	public class MyContentItem extends FileContentManager {

		/**
			@generated
		*/
		public MyContentItem(ContentItem parent, Item item, Variable fileNameVariable, Variable filePathVariable) throws CadseException {
			super(parent,item, fileNameVariable, filePathVariable);
		}

		@Override
		protected InputStream getDefaultImputStream() {
			AdlFactory factory = AdlFactory.eINSTANCE;
			AdlDefinition definition = factory.createAdlDefinition();
			definition.getArchitecturedefinition().add(createDefinition());
			
			try {
				ResourceSet resourceSet 		= new ResourceSetImpl();
				Resource 	resource			= resourceSet.createResource(URI.createURI(getItem().getName()+".adl"));
				
				resource.getContents().add(definition);
				
				ByteArrayOutputStream output	= new ByteArrayOutputStream();
				resource.save(output,null);
				return new ByteArrayInputStream(output.toByteArray());
			} catch (IOException e) {
				return super.getDefaultImputStream();
			}
		}
		
		protected ArchitectureDefinition createDefinition() {
			throw new UnsupportedOperationException("Must be refined by concrete subclasses");
		}
		
	}

	/**
	    @generated
	*/
	public ComponentManager() {
		super();
	}

	/**
		@generated
	*/
	@Override
	public String computeUniqueName(Item item, String name, Item parent, LinkType lt) {
		StringBuilder sb = new StringBuilder();
		try {
			Object value;
			Item currentItem;
			sb.append(parent.getName());
			sb.append(".");
			sb.append(name);
			return sb.toString();
		} catch (Throwable e) {
			e.printStackTrace();
			return "error";
		}
	}

	/**
		@generated
	*/
	@Override
	public String getDisplayName(Item item) {
		try {
			Object value;
			return item.getName();
		} catch (Throwable e) {
			e.printStackTrace();
			return "error";
		}
	}

	/**
		@generated
	*/
	@Override
	public ContentItem createContentManager(Item component) throws CadseException {
		MyContentItem cm = new MyContentItem(
			null,
			component, FileNameVariable.INSTANCE, FilePathVariable.INSTANCE
			);
		cm.setComposers(
		);
		cm.setExporters(
		);
		return cm;
	}

	/**
		get a link '#invert_part_components_to_Package' from 'Component' to 'Package'.
		@generated
	*/
	static public Link get_$_Invert_part_components_to_PackageLink(Item component) {
		return component.getOutgoingLink(MindCST.COMPONENT_lt__$_INVERT_PART_COMPONENTS_TO_PACKAGE);
	}

	/**
		get all link destination '#invert_part_components_to_Package' from 'Component' to 'Package'.
		@generated
	*/
	static public Item get_$_Invert_part_components_to_PackageAll(Item component) {
		return component.getOutgoingItem(MindCST.COMPONENT_lt__$_INVERT_PART_COMPONENTS_TO_PACKAGE, false);
	}

	/**
		get resolved link destination '#invert_part_components_to_Package' from 'Component' to 'Package'.
		@generated
	*/
	static public Item get_$_Invert_part_components_to_Package(Item component) {
		return component.getOutgoingItem(MindCST.COMPONENT_lt__$_INVERT_PART_COMPONENTS_TO_PACKAGE, true);
	}

	/**
		set a link '#invert_part_components_to_Package' from 'Component' to 'Package'.
		@generated
	*/
	static public void set_$_Invert_part_components_to_Package(Item component, Item value) throws CadseException {
		component.setOutgoingItem(MindCST.COMPONENT_lt__$_INVERT_PART_COMPONENTS_TO_PACKAGE,value);
	}

}

