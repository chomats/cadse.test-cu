package org.ow2.fractal.mind.cadse.managers;


import java.io.File;

import fede.workspace.eclipse.content.FolderContentManager;
import fede.workspace.eclipse.java.manager.JavaProjectContentManager;
import fr.imag.adele.cadse.core.CadseException;
import fr.imag.adele.cadse.core.ContentItem;
import fr.imag.adele.cadse.core.DefaultItemManager;
import fr.imag.adele.cadse.core.Item;
import fr.imag.adele.cadse.core.ItemType;
import fr.imag.adele.cadse.core.Link;
import fr.imag.adele.cadse.core.LinkType;
import fr.imag.adele.cadse.core.impl.var.VariableImpl;
import fr.imag.adele.cadse.core.var.ContextVariable;
import fr.imag.adele.cadse.core.var.Variable;

import java.util.Collection;
import java.util.List;
import org.eclipse.core.runtime.IPath;
import org.ow2.fractal.mind.cadse.MindCST;



/**
    @generated
*/
public class PackageManager extends DefaultItemManager {

	/**
	    @generated
	*/
	static final class FolderPathVariable extends VariableImpl {

		/**
		    @generated
		*/
		public final static Variable INSTANCE = new FolderPathVariable();

		/**
		 * @not generated
		 *   
		 * Calculates the source folder corresponding to a package. It is a subdirectory of the
		 * source folder of the parent library
		 * 
		 */
		public String compute(ContextVariable context, Item itemCurrent) {
			StringBuilder sb = new StringBuilder();
			try {
				
				ContentItem parentContentItem = itemCurrent.getPartParent().getContentItem();
				if (parentContentItem instanceof JavaProjectContentManager) {
					JavaProjectContentManager javaContent = (JavaProjectContentManager) parentContentItem;
					sb.append(javaContent.getJavaSourceElement(context).getPath().makeRelativeTo(javaContent.getJavaProject(context).getPath()));
					sb.append(IPath.SEPARATOR);
				}
				sb.append(itemCurrent.getName().replace('.',IPath.SEPARATOR));
				return sb.toString();
			} catch (Throwable e) {
				e.printStackTrace();
				return "error";
			}
		}
	}

	/**
	    @generated
	*/
	public PackageManager() {
		super();
	}

	/**
		@generated
	*/
	@Override
	public String computeUniqueName(Item item, String name, Item parent, LinkType lt) {
		StringBuilder sb = new StringBuilder();
		try {
			Object value;
			Item currentItem;
			sb.append(parent.getQualifiedName());
			sb.append(".");
			sb.append(name);
			return sb.toString();
		} catch (Throwable e) {
			e.printStackTrace();
			return "error";
		}
	}

	/**
		@generated
	*/
	@Override
	public String getDisplayName(Item item) {
		try {
			Object value;
			return item.getName();
		} catch (Throwable e) {
			e.printStackTrace();
			return "error";
		}
	}

	/**
		@generated
	*/
	@Override
	public ContentItem createContentManager(Item _package) throws CadseException {
		FolderContentManager cm = new FolderContentManager(
			null,
			_package, FolderPathVariable.INSTANCE
			);
		cm.setComposers(
		);
		cm.setExporters(
		);
		return cm;
	}

	/**
		get a link '#invert_part_packages_to_Library' from 'Package' to 'Library'.
		@generated
	*/
	static public Link get_$_Invert_part_packages_to_LibraryLink(Item _package) {
		return _package.getOutgoingLink(MindCST.PACKAGE_lt__$_INVERT_PART_PACKAGES_TO_LIBRARY);
	}

	/**
		get all link destination '#invert_part_packages_to_Library' from 'Package' to 'Library'.
		@generated
	*/
	static public Item get_$_Invert_part_packages_to_LibraryAll(Item _package) {
		return _package.getOutgoingItem(MindCST.PACKAGE_lt__$_INVERT_PART_PACKAGES_TO_LIBRARY, false);
	}

	/**
		get resolved link destination '#invert_part_packages_to_Library' from 'Package' to 'Library'.
		@generated
	*/
	static public Item get_$_Invert_part_packages_to_Library(Item _package) {
		return _package.getOutgoingItem(MindCST.PACKAGE_lt__$_INVERT_PART_PACKAGES_TO_LIBRARY, true);
	}

	/**
		set a link '#invert_part_packages_to_Library' from 'Package' to 'Library'.
		@generated
	*/
	static public void set_$_Invert_part_packages_to_Library(Item _package, Item value) throws CadseException {
		_package.setOutgoingItem(MindCST.PACKAGE_lt__$_INVERT_PART_PACKAGES_TO_LIBRARY,value);
	}

	/**
		get  links 'components' from 'Package' to 'Primitive'.
        @generated
    */
    static public List<Link> getComponentsLink(Item _package) {
        return _package.getOutgoingLinks(MindCST.PACKAGE_lt_COMPONENTS);
    }

	/**
        @generated
    */
    static public Collection<Item> getComponentsAll(Item _package) {
        return _package.getOutgoingItems(MindCST.PACKAGE_lt_COMPONENTS, false);
    }

	/**
        @generated
    */
    static public Collection<Item> getComponents(Item _package) {
        return _package.getOutgoingItems(MindCST.PACKAGE_lt_COMPONENTS,true);
    }

	/**
        @generated
    */
    static public void addComponents(Item _package, Item value) throws CadseException {
        _package.addOutgoingItem(MindCST.PACKAGE_lt_COMPONENTS,value);
    }

	/**
        @generated
    */
    static public void removeComponents(Item _package, Item value) throws CadseException {
        _package.removeOutgoingItem(MindCST.PACKAGE_lt_COMPONENTS,value);
    }

}

