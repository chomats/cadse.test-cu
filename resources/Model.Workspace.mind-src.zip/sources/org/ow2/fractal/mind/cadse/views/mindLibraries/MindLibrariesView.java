package org.ow2.fractal.mind.cadse.views.mindLibraries;


import fr.imag.adele.cadse.core.*;
import fr.imag.adele.cadse.eclipse.view.AbstractCadseTreeViewUI;
import fr.imag.adele.cadse.eclipse.view.AbstractCadseView;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import org.eclipse.ui.IViewSite;
import org.ow2.fractal.mind.cadse.MindCST;

/**
	@generated
*/
class MindLibrariesViewUI extends AbstractCadseTreeViewUI {


	/**
		@generated
	*/
	public MindLibrariesViewUI(IViewSite site) {
		super(site);
		setRecomputeChildren(true);
	}

	/**
		@generated
	*/
	HashSet<ItemType> firstItemType = null;

	/**
		@generated
	*/
	HashSet<ItemType> refItemType = null;

	/**
		@generated
	*/
	HashSet<ItemType> allItemType = null;

	/**
		@generated
	*/
	HashSet<LinkType> agLinkType = null;

	/**
		@generated
	*/
	HashMap<LinkType, String> displayString = null;

	/**
		@generated
	*/
	HashSet<LinkType> createLinkType = null;

	/**
		@generated
	*/
	HashSet<LinkType> allLinkType = null;

	/**
		@generated
	*/
	private void init() {
		allItemType = new HashSet<ItemType>();
		if (MindCST.PACKAGE != null) {
			allItemType.add(MindCST.PACKAGE);
			allItemType.addAll(Arrays.asList(MindCST.PACKAGE.getSubTypes()));
		}
		if (MindCST.LIBRARY != null) {
			allItemType.add(MindCST.LIBRARY);
			allItemType.addAll(Arrays.asList(MindCST.LIBRARY.getSubTypes()));
		}
		if (MindCST.COMPONENT != null) {
			allItemType.add(MindCST.COMPONENT);
			allItemType.addAll(Arrays.asList(MindCST.COMPONENT.getSubTypes()));
		}

		firstItemType = new HashSet<ItemType>();
		
		if (MindCST.LIBRARY != null) {
			firstItemType.add(MindCST.LIBRARY);
			firstItemType.addAll(Arrays.asList(MindCST.LIBRARY.getSubTypes()));
		}

		agLinkType = new HashSet<LinkType>();
		
		if (MindCST.PACKAGE_lt_COMPONENTS != null)
			agLinkType.add(MindCST.PACKAGE_lt_COMPONENTS);
		if (MindCST.LIBRARY_lt_PACKAGES != null)
			agLinkType.add(MindCST.LIBRARY_lt_PACKAGES);

		createLinkType = new HashSet<LinkType>();
		if (MindCST.PACKAGE_lt_COMPONENTS != null)
			createLinkType.add(MindCST.PACKAGE_lt_COMPONENTS);
		if (MindCST.LIBRARY_lt_PACKAGES != null)
			createLinkType.add(MindCST.LIBRARY_lt_PACKAGES);

		allLinkType = new HashSet<LinkType>();
		if (MindCST.PACKAGE_lt_COMPONENTS != null)
			allLinkType.add(MindCST.PACKAGE_lt_COMPONENTS);
		if (MindCST.LIBRARY_lt_PACKAGES != null)
			allLinkType.add(MindCST.LIBRARY_lt_PACKAGES);

		refItemType = new HashSet<ItemType>();

		
	}


	/**
		@generated
	*/
	@Override
	public ItemType[] getFirstItemType(LogicalWorkspace model) {
		if (firstItemType == null)
			init();
		return (ItemType[]) firstItemType.toArray(new ItemType[firstItemType.size()]);
	}

	/**
		@generated
	*/
	@Override
	public boolean isAggregationLink(Link link) {
		if (firstItemType == null)
			init();
		return agLinkType.contains(link.getLinkType());
	}

	/**
		@generated
	*/
	@Override
	public boolean isCreateLink(LinkType link) {
		if (firstItemType == null)
			init();
		return createLinkType.contains(link);
	}

	/**
		@generated
	*/
	@Override
	public boolean canCreateLinkFrom(Item parentitem, LinkType link) {
		return isCreateLink(link);
	}

	/**
		@generated
	*/
	@Override
	public String getDislplayCreate(LinkType link) {
		if (displayString == null) return null;

		return displayString.get(link);
	}


	/**
		@generated
	*/
	@Override
	public boolean isFirstItemType(ItemType it, LogicalWorkspace cadseModel) {
		if (firstItemType == null)
			init();
		return firstItemType.contains(it);
	}

	/**
		@generated
	*/
	@Override
	public boolean isRefItemType(ItemType it, LogicalWorkspace cadseModel) {
		if (refItemType == null)
			init();
		return refItemType.contains(it);
	}


	/**
		@generated
	*/
	@Override
	public boolean isItemType(ItemType it, LogicalWorkspace cadseModel) {
		if (allItemType == null)
			init();
		return allItemType.contains(it);
	}



	/**
		@generated
	*/
	@Override
	protected boolean isLink(Link link) {
		if (allLinkType == null)
			init();
		return allLinkType.contains(link.getLinkType());
	}

}

/**
	@generated
*/
public class MindLibrariesView extends AbstractCadseView {

	/**
		@generated
	*/
	@Override
	protected AbstractCadseTreeViewUI createUIController(IViewSite site) {
		return new MindLibrariesViewUI(site);
	}
}

