package org.ow2.fractal.mind.cadse.pages;

import fede.workspace.model.manager.properties.FieldsCore;
import fede.workspace.model.manager.properties.IInteractionControllerForList;
import fede.workspace.model.manager.properties.impl.ic.IC_LinkForBrowser_Combo_List;
import fede.workspace.model.manager.properties.impl.mc.LinkModelController;
import fede.workspace.model.manager.properties.impl.ui.DListUI;
import fede.workspace.model.manager.properties.impl.ui.DTextUI;
import fr.imag.adele.cadse.core.IItemNode;
import fr.imag.adele.cadse.core.Item;
import fr.imag.adele.cadse.core.ItemType;
import fr.imag.adele.cadse.core.Link;
import fr.imag.adele.cadse.core.LinkType;
import fr.imag.adele.cadse.core.impl.ui.PageImpl;
import fr.imag.adele.cadse.core.ui.EPosLabel;
import fr.imag.adele.cadse.core.ui.IActionPage;
import fr.imag.adele.cadse.core.ui.IModelController;
import fr.imag.adele.cadse.core.ui.IPage;
import fr.imag.adele.cadse.core.ui.PageFactory;
import fr.imag.adele.cadse.core.ui.UIField;
import org.ow2.fractal.mind.cadse.MindCST;

/**
 @generated
 */
public class LibraryModificationPageLibrary_ModificationPage extends PageImpl {

	/**
	    @generated
	 */
	public Item item;

	/**
	    @generated
	 */
	protected DTextUI __short_name__;

	/**
	    @generated
	 */
	protected DListUI fieldPackages;

	/**
	    @generated
	 */
	protected LibraryModificationPageLibrary_ModificationPage(String id,
			String label, String title, String description,
			boolean isPageComplete, int hspan) {
		super(id, label, title, description, isPageComplete, hspan);
	}

	/**
	    @generated
	 */
	public LibraryModificationPageLibrary_ModificationPage(Item item) {
		super("modification-page-Library", "Library", "Library", "", false, 3);
		this.item = item;
		this.__short_name__ = createInternalNameField();
		this.fieldPackages = createFieldPackages();
		setActionPage(null);
		addLast(this.__short_name__, this.fieldPackages);

		registerListener();
	}

	protected void registerListener() {
		// add init and register
	}

	/**
	    @generated
	 */
	public DTextUI createInternalNameField() {
		return FieldsCore.createUniqueNameField();
	}

	/**
	    @generated
	 */
	public DListUI createFieldPackages() {
		LinkModelController mc = new LinkModelController(false, null,
				MindCST.LIBRARY_lt_PACKAGES);
		IC_LinkForBrowser_Combo_List ic = new IC_LinkForBrowser_Combo_List(
				"Select a value.", "Select a value.",
				MindCST.LIBRARY_lt_PACKAGES);
		return new DListUI(MindCST.LIBRARY_lt_PACKAGES.getName(), "packages",
				EPosLabel.top, mc, ic, true, false, false, false);
	}

}
