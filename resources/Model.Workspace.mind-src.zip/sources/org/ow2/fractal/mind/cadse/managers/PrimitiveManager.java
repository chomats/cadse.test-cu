package org.ow2.fractal.mind.cadse.managers;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import fede.workspace.eclipse.content.FileContentManager;
import fede.workspace.eclipse.content.FolderContentManager;
import fede.workspace.eclipse.java.manager.JavaProjectContentManager;
import fr.imag.adele.cadse.core.CadseException;
import fr.imag.adele.cadse.core.ContentItem;
import fr.imag.adele.cadse.core.DefaultItemManager;
import fr.imag.adele.cadse.core.Item;
import fr.imag.adele.cadse.core.ItemType;
import fr.imag.adele.cadse.core.Link;
import fr.imag.adele.cadse.core.LinkType;
import fr.imag.adele.cadse.core.impl.var.VariableImpl;
import fr.imag.adele.cadse.core.var.ContextVariable;
import fr.imag.adele.cadse.core.var.Variable;

import org.eclipse.core.runtime.IPath;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.ow2.fractal.mind.cadse.MindCST;

import adl.AdlDefinition;
import adl.AdlFactory;
import adl.ArchitectureDefinition;
import adl.PrimitiveComponentDefinition;



/**
    @generated
*/
public class PrimitiveManager extends ComponentManager {

	/**
	    @generated
	*/
	static final class FileNameVariable extends VariableImpl {

		/**
		    @generated
		*/
		public final static Variable INSTANCE = new FileNameVariable();

		/**
		    @generated
		*/
		public String compute(ContextVariable context, Item itemCurrent) {
			StringBuilder sb = new StringBuilder();
			try {
				Object value;
				sb.append(context.getName(itemCurrent));
				sb.append(".adl");
				return sb.toString();
			} catch (Throwable e) {
				e.printStackTrace();
				return "error";
			}
		}
	}

	/**
	    @generated
	*/
	static final class FilePathVariable extends VariableImpl {

		/**
		    @generated
		*/
		public final static Variable INSTANCE = new FilePathVariable();

		/**
		    @generated
		*/
		public String compute(ContextVariable context, Item itemCurrent) {
			try {
				return "/";
			} catch (Throwable e) {
				e.printStackTrace();
				return "error";
			}
		}
	}

	/**
		@generated
	*/
	public class MyContentItem extends ComponentManager.MyContentItem {

		/**
			@generated
		*/
		public MyContentItem(ContentItem parent, Item item, Variable fileNameVariable, Variable filePathVariable) throws CadseException {
			super(parent,item, fileNameVariable, filePathVariable);
		}
		
		@Override
		protected ArchitectureDefinition createDefinition() {
			AdlFactory factory = AdlFactory.eINSTANCE;
			PrimitiveComponentDefinition primitive = factory.createPrimitiveComponentDefinition();
			primitive.setAbstract(false);
			primitive.setName(getItem().getQualifiedName());
			return primitive;
		} 
		

	}

	/**
	    @generated
	*/
	public PrimitiveManager() {
		super();
	}



	/**
		@generated
	*/
	@Override
	public String computeUniqueName(Item item, String name, Item parent, LinkType lt) {
		StringBuilder sb = new StringBuilder();
		try {
			Object value;
			Item currentItem;
			sb.append(parent.getName());
			sb.append(".");
			sb.append(name);
			return sb.toString();
		} catch (Throwable e) {
			e.printStackTrace();
			return "error";
		}
	}



	/**
		@generated
	*/
	@Override
	public String getDisplayName(Item item) {
		try {
			Object value;
			return item.getName();
		} catch (Throwable e) {
			e.printStackTrace();
			return "error";
		}
	}

	/**
		@generated
	*/
	@Override
	public ContentItem createContentManager(Item primitive) throws CadseException {
		MyContentItem cm = new MyContentItem(
			null,
			primitive, FileNameVariable.INSTANCE, FilePathVariable.INSTANCE
			);
		cm.setComposers(
		);
		cm.setExporters(
		);
		return cm;
	}

}

